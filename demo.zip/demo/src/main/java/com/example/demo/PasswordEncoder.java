package com.example.demo;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoder {

	BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
	
}
